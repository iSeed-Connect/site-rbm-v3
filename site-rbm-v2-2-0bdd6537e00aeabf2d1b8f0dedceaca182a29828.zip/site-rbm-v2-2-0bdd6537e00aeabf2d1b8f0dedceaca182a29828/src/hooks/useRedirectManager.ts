import { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

// Lista de redirecionamentos para URLs antigas ou comuns
const redirectMap: { [key: string]: string } = {
  '/home': '/',
  '/index': '/',
  '/inicio': '/',
  '/galeria': '/gallery',
  '/fotos': '/gallery',
  '/contato': '/#contact',
  '/sobre': '/#about',
  '/servicos': '/#services',
  '/equipe': '/trabalhe-conosco',
  '/vagas': '/trabalhe-conosco',
  '/emprego': '/trabalhe-conosco',
  '/carreira': '/trabalhe-conosco',
  '/jobs': '/trabalhe-conosco',
};

export const useRedirectManager = () => {
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const path = location.pathname.toLowerCase();
    
    // Verifica se existe um redirecionamento para esta rota
    if (redirectMap[path]) {
      const targetPath = redirectMap[path];
      
      // Se for um anchor link, navega para a home e depois scroll
      if (targetPath.includes('#')) {
        const [route, anchor] = targetPath.split('#');
        navigate(route || '/', { replace: true });
        
        // Aguarda a navegação e depois faz o scroll
        setTimeout(() => {
          const element = document.getElementById(anchor);
          if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
          }
        }, 100);
      } else {
        // Redirecionamento simples
        navigate(targetPath, { replace: true });
      }
    }
    
    // Remove trailing slashes (exceto para root)
    if (path.length > 1 && path.endsWith('/')) {
      navigate(path.slice(0, -1), { replace: true });
    }
    
    // Converte URLs com query params mal formadas
    const searchParams = new URLSearchParams(location.search);
    if (searchParams.has('page')) {
      const page = searchParams.get('page');
      if (page === 'gallery' || page === 'galeria') {
        navigate('/gallery', { replace: true });
      } else if (page === 'contact' || page === 'contato') {
        navigate('/#contact', { replace: true });
      }
    }
  }, [location, navigate]);
};