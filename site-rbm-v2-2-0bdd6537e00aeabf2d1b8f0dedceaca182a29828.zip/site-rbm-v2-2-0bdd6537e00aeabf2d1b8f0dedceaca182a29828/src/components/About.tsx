import { Button } from "@/components/ui/button";
import { CheckCircle, Award, Users, Target } from "lucide-react";
import aboutImage from "@/assets/equipe-brasif-rbm.jpg";

export const About = () => {
  const features = [
    "Mais de 20 anos de experiência no mercado",
    "Equipe especializada e treinada",
    "Atendimento personalizado e dedicado",
    "Presença em eventos de grande porte",
  ];

  const values = [
    {
      icon: Award,
      title: "Excelência",
      description: "Buscamos sempre a perfeição em cada detalhe do seu evento.",
    },
    {
      icon: Users,
      title: "Dedicação",
      description: "Nossa equipe está comprometida com o sucesso do seu evento.",
    },
    {
      icon: Target,
      title: "Compromisso",
      description: "Cumprimos prazos e superamos expectativas sempre.",
    },
  ];

  return (
    <section id="about" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Mais de duas décadas transformando eventos em{" "}
            <span className="text-primary">experiências inesquecíveis</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Com mais de 20 anos de experiência, a RBM Service e Eventos é referência 
            na prestação de serviços promovendo a excelência em eventos corporativos, 
            institucionais e governamentais.
          </p>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-20">
          {/* Image */}
          <div className="relative">
            <img
              src={aboutImage}
              alt="Equipe RBM Service e Eventos"
              className="rounded-2xl shadow-elegant w-full h-[400px] object-cover"
            />
            <div className="absolute -bottom-6 -right-6 bg-gradient-primary text-white p-6 rounded-2xl shadow-glow">
              <div className="text-3xl font-bold">20+</div>
              <div className="text-sm">Anos de experiência</div>
            </div>
          </div>

          {/* Content */}
          <div>
            <h3 className="text-3xl font-bold mb-6">
              Presença sólida nos maiores eventos de Minas Gerais
            </h3>
            <p className="text-lg text-muted-foreground mb-8">
              Atuamos com excelência em eventos empresariais, shows, cerimônias oficiais, 
              agendas públicas e grandes produções — com estrutura, equipe e operação sob medida.
            </p>

            {/* Features List */}
            <div className="space-y-4 mb-8">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <CheckCircle className="h-6 w-6 text-primary flex-shrink-0" />
                  <span className="text-foreground">{feature}</span>
                </div>
              ))}
            </div>

            <Button 
              variant="hero" 
              size="lg"
              onClick={() => {
                document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              Saiba Mais Sobre Nós
            </Button>
          </div>
        </div>

        {/* Values */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {values.map((value, index) => {
            const IconComponent = value.icon;
            return (
              <div
                key={index}
                className="text-center p-8 rounded-2xl bg-card hover:shadow-elegant transition-all duration-300 hover:transform hover:scale-105"
              >
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-primary rounded-full mb-6">
                  <IconComponent className="h-8 w-8 text-white" />
                </div>
                <h4 className="text-2xl font-bold mb-4">{value.title}</h4>
                <p className="text-muted-foreground">{value.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};