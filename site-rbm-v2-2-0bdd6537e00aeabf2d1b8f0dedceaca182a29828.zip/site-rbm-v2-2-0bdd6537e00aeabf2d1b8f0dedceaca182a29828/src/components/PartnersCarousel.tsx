import { useEffect, useRef } from "react";
import simetriaLogo from "@/assets/partners/simetria.png";
import expominasLogo from "@/assets/partners/expominas.png";
import beloturLogo from "@/assets/partners/belotur.png";
import segovLogo from "@/assets/partners/segov.png";
import tjmgLogo from "@/assets/partners/tjmg.png";
import arenaMrvLogo from "@/assets/partners/arena-mrv.png";
import mineiraoLogo from "@/assets/partners/mineirao.png";
import eppoLogo from "@/assets/partners/eppo.png";
import brasifLogo from "@/assets/partners/brasif.png";

const partnerLogos = [
  { name: "Simetria Brasil", logo: simetriaLogo },
  { name: "Expominas", logo: expominasLogo },
  { name: "Belotur", logo: beloturLogo },
  { name: "SEGOV", logo: segovLogo },
  { name: "TJMG", logo: tjmgLogo },
  { name: "Arena MRV", logo: arenaMrvLogo },
  { name: "Mineirão", logo: mineiraoLogo },
  { name: "EPPO", logo: eppoLogo },
  { name: "Brasif Máquinas", logo: brasifLogo },
];

export const PartnersCarousel = () => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const scrollContainer = scrollRef.current;
    if (!scrollContainer) return;

    const scrollWidth = scrollContainer.scrollWidth;
    const clientWidth = scrollContainer.clientWidth;
    
    let scrollPosition = 0;
    const scrollSpeed = 0.5;

    const scroll = () => {
      scrollPosition += scrollSpeed;
      
      if (scrollPosition >= scrollWidth / 2) {
        scrollPosition = 0;
      }
      
      scrollContainer.scrollLeft = scrollPosition;
      requestAnimationFrame(scroll);
    };

    const animationId = requestAnimationFrame(scroll);
    
    return () => cancelAnimationFrame(animationId);
  }, []);

  // Duplicate logos for seamless scroll
  const duplicatedLogos = [...partnerLogos, ...partnerLogos];

  return (
    <section className="py-12 bg-background border-y border-border/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8">
          <h3 className="text-3xl font-bold mb-2">
            Parceiros e <span className="text-primary">Clientes</span>
          </h3>
          <p className="text-lg text-muted-foreground">
            Empresas que confiam na nossa excelência
          </p>
        </div>
        
        <div 
          ref={scrollRef}
          className="flex overflow-hidden items-center"
          style={{ scrollBehavior: 'auto' }}
        >
          {duplicatedLogos.map((partner, index) => (
            <div
              key={index}
              className="flex-shrink-0 flex items-center justify-center rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors duration-300 border-r border-border/30"
              style={{ minWidth: '160px', height: '80px' }}
            >
              <img
                src={partner.logo}
                alt={partner.name}
                className="max-w-[140px] max-h-[60px] object-contain opacity-70 hover:opacity-100 transition-opacity duration-300 grayscale hover:grayscale-0"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};