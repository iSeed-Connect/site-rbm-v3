import { Card, CardContent } from "@/components/ui/card";
import { Star, Quote } from "lucide-react";
import praticaLogo from "@/assets/testimonials/pratica.png";
import segovLogo from "@/assets/testimonials/segov.png";
import tjmgLogo from "@/assets/testimonials/tjmg.png";

export const Testimonials = () => {
  const testimonials = [
    {
      name: "Pratica Produtora",
      role: "Empresa de Eventos",
      content: "Quero agradecer a você e à sua equipe pelo trabalho excepcional. Todos os dias demonstraram disposição, comprometimento e profissionalismo, atuando como uma verdadeira força-tarefa. A dedicação de todos fez toda a diferença.",
      rating: 5,
      avatar: praticaLogo
    },
    {
      name: "SEGOV",
      role: "Secretaria de Governo",
      content: "Gostaria de agradecer pelo excelente trabalho realizado e pela seleção criteriosa da equipe. Os carregadores escolhidos foram, sem dúvida, os melhores até hoje: extremamente competentes, comprometidos e sempre prontos a contribuir com ideias que trouxeram ótimos resultados. Além disso, você e sua equipe executaram tudo com excelência, sem causar qualquer estresse. Foi um trabalho impecável, digno de reconhecimento. Show de bola!",
      rating: 5,
      avatar: segovLogo
    },
    {
      name: "TJMG",
      role: "Tribunal de Justiça de Minas Gerais",
      content: "Recebemos diversos elogios pela recepção. O trabalho de toda a equipe foi exemplar: organizado, ágil e executado com dedicação. Esse profissionalismo garantiu que tudo funcionasse perfeitamente. Agradecemos imensamente pelo apoio, que fez toda a diferença.",
      rating: 5,
      avatar: tjmgLogo
    }
  ];

  return (
    <section id="testimonials" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Depoimentos de <span className="text-primary">Clientes</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Confira o que nossos clientes têm a dizer sobre os serviços prestados pela RBM Service e Eventos.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="hover:shadow-elegant transition-all duration-300 hover:transform hover:scale-105 border-0 relative overflow-hidden">
              {/* Quote Icon */}
              <div className="absolute top-4 right-4 opacity-10">
                <Quote className="h-12 w-12 text-primary" />
              </div>
              
              <CardContent className="p-8">
                {/* Rating */}
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-secondary fill-current" />
                  ))}
                </div>

                {/* Content */}
                <p className="text-muted-foreground mb-6 leading-relaxed italic">
                  "{testimonial.content}"
                </p>

                {/* Author */}
                <div className="flex items-center space-x-4">
                  <img
                    src={testimonial.avatar}
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <h4 className="font-semibold text-foreground">{testimonial.name}</h4>
                    <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Trust Indicators */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div>
            <div className="text-3xl font-bold text-primary mb-2">500+</div>
            <div className="text-muted-foreground">Eventos Realizados</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-primary mb-2">100%</div>
            <div className="text-muted-foreground">Satisfação</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-primary mb-2">20+</div>
            <div className="text-muted-foreground">Anos de Experiência</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-primary mb-2">24/7</div>
            <div className="text-muted-foreground">Suporte Dedicado</div>
          </div>
        </div>
      </div>
    </section>
  );
};