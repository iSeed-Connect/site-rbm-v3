import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { 
  Mail, 
  Phone, 
  MapPin, 
  Clock, 
  Instagram, 
  MessageCircle,
  Send,
  Loader2,
  CheckCircle
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const formSchema = z.object({
  name: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  company: z.string().optional(),
  email: z.string().email("Email inválido"),
  phone: z.string().min(10, "Telefone deve ter pelo menos 10 dígitos"),
  eventType: z.string().optional(),
  eventDate: z.string().optional(),
  message: z.string().min(10, "Mensagem deve ter pelo menos 10 caracteres"),
});

export const Contact = () => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      company: "",
      email: "",
      phone: "",
      eventType: "",
      eventDate: "",
      message: "",
    },
  });

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    try {
      setIsLoading(true);
      const response = await fetch('https://n8n.main.iseed.cloud/webhook/forms/solicitar-orcamento-rbm', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(values),
      });
      
      if (response.ok) {
        toast({
          title: "Mensagem enviada com sucesso!",
          description: "Entraremos em contato em até 24 horas úteis.",
        });
        form.reset();
      } else {
        throw new Error('Erro no envio');
      }
    } catch (error) {
      toast({
        title: "Erro ao enviar mensagem",
        description: "Tente novamente ou entre em contato via WhatsApp.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  const contactInfo = [
    {
      icon: Mail,
      title: "Email",
      value: "contato@rbmserviceeventos.com.br",
      link: "mailto:contato@rbmserviceeventos.com.br"
    },
    {
      icon: Phone,
      title: "Telefone",
      value: "(31) 99905-7590",
      link: "https://wa.me/553199057590"
    },
    {
      icon: MapPin,
      title: "Localização",
      value: "Belo Horizonte, MG",
      link: "#"
    },
    {
      icon: Clock,
      title: "Horário",
      value: "Seg - Seg: 6h às 18h",
      link: "#"
    }
  ];

  const socialLinks = [
    {
      icon: Instagram,
      name: "Instagram",
      url: "https://www.instagram.com/rbmserviceeventos/",
      color: "hover:bg-pink-500"
    },
    {
      icon: MessageCircle,
      name: "WhatsApp",
      url: "https://wa.me/553199057590",
      color: "hover:bg-green-500"
    }
  ];

  return (
    <section id="contact" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Entre em <span className="text-primary">Contato</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Estamos prontos para transformar seu evento em uma experiência inesquecível. 
            Entre em contato conosco e solicite seu orçamento personalizado.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div className="mt-8">
            <h3 className="text-3xl font-bold mb-8">Entre em contato com nosso time</h3>
            
            {/* Contact Cards */}
            <div className="space-y-4 mb-8">
              {contactInfo.map((item, index) => {
                const IconComponent = item.icon;
                return (
                  <div key={index} className="flex items-center space-x-4 p-4 rounded-xl bg-card hover:shadow-md transition-all duration-300">
                    <div className="flex-shrink-0">
                      <div className="inline-flex items-center justify-center w-12 h-12 bg-gradient-primary rounded-lg">
                        <IconComponent className="h-6 w-6 text-white" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg font-semibold text-foreground mb-1">{item.title}</h4>
                      <a 
                        href={item.link}
                        className="text-muted-foreground hover:text-primary transition-colors text-base"
                      >
                        {item.value}
                      </a>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Quick Contact Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Button 
                variant="hero" 
                size="lg" 
                className="text-base px-6"
                onClick={() => window.open('https://wa.me/553199057590', '_blank')}
              >
                <MessageCircle className="mr-2 h-5 w-5" />
                Fale Conosco no WhatsApp
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="text-base px-6"
                onClick={() => window.location.href = 'mailto:contato@rbmserviceeventos.com.br'}
              >
                <Mail className="mr-2 h-5 w-5" />
                Enviar Email
              </Button>
            </div>
          </div>

          {/* Contact Form */}
          <Card className="border-0 shadow-elegant">
            <CardHeader>
              <CardTitle className="text-2xl">Solicite seu Orçamento</CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base">Nome *</FormLabel>
                          <FormControl>
                            <Input placeholder="Seu nome completo" className="text-base" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="company"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base">Empresa</FormLabel>
                          <FormControl>
                            <Input placeholder="Nome da empresa" className="text-base" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base">Email *</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="seu@email.com" className="text-base" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base">Telefone *</FormLabel>
                          <FormControl>
                            <Input placeholder="(31) 99999-9999" className="text-base" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="eventType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-base">Tipo de Evento</FormLabel>
                        <FormControl>
                          <Input placeholder="Ex: Evento corporativo, cerimônia oficial..." className="text-base" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="eventDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-base">Data do Evento</FormLabel>
                        <FormControl>
                          <Input type="date" className="text-base" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-base">Mensagem *</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Descreva seu evento e os serviços que precisa..."
                            rows={4}
                            className="text-base"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button type="submit" variant="hero" size="lg" className="w-full text-base" disabled={isLoading}>
                    {isLoading ? (
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    ) : (
                      <Send className="mr-2 h-5 w-5" />
                    )}
                    {isLoading ? "Enviando..." : "Enviar Solicitação"}
                  </Button>

                  <p className="text-sm text-muted-foreground text-center">
                    Entraremos em contato em até 24 horas úteis.
                  </p>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};