import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useNavigate, Link } from "react-router-dom";
import rbmLogo from "@/assets/rbm-logo-final-transparent.png";

export const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();

  const menuItems = [
    { name: "Início", href: "/" },
    { name: "Sobre", href: "#about" },
    { name: "Serviços", href: "#services" },
    { name: "Galeria", href: "/gallery" },
    { name: "Trabalhe Conosco", href: "/trabalhe-conosco" },
    { name: "Contato", href: "#contact" },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-card/95 backdrop-blur-md border-b border-border transition-all duration-300">
      <div className="container mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-24 md:h-28 lg:h-32">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <img 
              src={rbmLogo} 
              alt="RBM Service e Eventos" 
              className="h-16 w-auto md:h-20 lg:h-24 object-contain"
              style={{ 
                filter: 'drop-shadow(0 2px 8px rgba(0,0,0,0.1))'
              }}
            />
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            {menuItems.map((item) => (
              item.href.startsWith('/') ? (
                <Link
                  key={item.name}
                  to={item.href}
                  className="text-foreground hover:text-primary transition-all duration-300 font-medium hover:scale-105 relative after:content-[''] after:absolute after:w-full after:scale-x-0 after:h-0.5 after:bottom-0 after:left-0 after:bg-primary after:origin-bottom-right after:transition-transform after:duration-300 hover:after:scale-x-100 hover:after:origin-bottom-left"
                >
                  {item.name}
                </Link>
              ) : (
                <a
                  key={item.name}
                  href={item.href}
                  className="text-foreground hover:text-primary transition-all duration-300 font-medium hover:scale-105 relative after:content-[''] after:absolute after:w-full after:scale-x-0 after:h-0.5 after:bottom-0 after:left-0 after:bg-primary after:origin-bottom-right after:transition-transform after:duration-300 hover:after:scale-x-100 hover:after:origin-bottom-left"
                  onClick={(e) => {
                    e.preventDefault();
                    if (window.location.pathname !== '/') {
                      navigate('/');
                      setTimeout(() => {
                        const element = document.getElementById(item.href.substring(1));
                        element?.scrollIntoView({ behavior: 'smooth' });
                      }, 100);
                    } else {
                      const element = document.getElementById(item.href.substring(1));
                      element?.scrollIntoView({ behavior: 'smooth' });
                    }
                  }}
                >
                  {item.name}
                </a>
              )
            ))}
          </nav>

          {/* CTA Button */}
          <div className="hidden lg:flex items-center space-x-4">
            <Button 
              variant="cta" 
              size="sm" 
              className="hover:scale-105 transition-transform duration-300"
              onClick={() => navigate('/trabalhe-conosco')}
            >
              Trabalhe Conosco
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-3 rounded-lg hover:bg-muted transition-all duration-300 hover:scale-105"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
          >
            <div className="relative w-6 h-6">
              <span className={`absolute block h-0.5 w-6 bg-foreground transform transition-all duration-300 ${isMenuOpen ? 'rotate-45 top-3' : 'top-1'}`} />
              <span className={`absolute block h-0.5 w-6 bg-foreground transition-all duration-300 ${isMenuOpen ? 'opacity-0' : 'top-3'}`} />
              <span className={`absolute block h-0.5 w-6 bg-foreground transform transition-all duration-300 ${isMenuOpen ? '-rotate-45 top-3' : 'top-5'}`} />
            </div>
          </button>
        </div>

        {/* Mobile Navigation */}
        <div className={`lg:hidden overflow-hidden transition-all duration-500 ease-in-out ${isMenuOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}`}>
          <div className="py-6 border-t border-border bg-card/95 backdrop-blur-md">
            <nav className="flex flex-col space-y-1">
              {menuItems.map((item, index) => (
                item.href.startsWith('/') ? (
                  <Link
                    key={item.name}
                    to={item.href}
                    className="text-foreground hover:text-primary hover:bg-muted transition-all duration-300 font-medium py-3 px-4 rounded-lg mx-2 transform hover:scale-105 hover:translate-x-2"
                    onClick={() => setIsMenuOpen(false)}
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    {item.name}
                  </Link>
                ) : (
                  <a
                    key={item.name}
                    href={item.href}
                    className="text-foreground hover:text-primary hover:bg-muted transition-all duration-300 font-medium py-3 px-4 rounded-lg mx-2 transform hover:scale-105 hover:translate-x-2"
                    onClick={(e) => {
                      setIsMenuOpen(false);
                      e.preventDefault();
                      if (window.location.pathname !== '/') {
                        navigate('/');
                        setTimeout(() => {
                          const element = document.getElementById(item.href.substring(1));
                          element?.scrollIntoView({ behavior: 'smooth' });
                        }, 100);
                      } else {
                        const element = document.getElementById(item.href.substring(1));
                        element?.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    {item.name}
                  </a>
                )
              ))}
              <div className="px-6 pt-4">
                <Button 
                  variant="cta" 
                  size="sm" 
                  className="w-full hover:scale-105 transition-transform duration-300"
                  onClick={() => {
                    setIsMenuOpen(false);
                    navigate('/trabalhe-conosco');
                  }}
                >
                  Trabalhe Conosco
                </Button>
              </div>
            </nav>
          </div>
        </div>
      </div>
    </header>
  );
};