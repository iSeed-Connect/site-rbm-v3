import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

import { 
  Users, 
  Shield, 
  Briefcase, 
  Settings, 
  UserCheck, 
  ClipboardCheck,
  HardHat,
  Camera,
  Trash2
} from "lucide-react";

export const Services = () => {
  const serviceCategories = [
    {
      title: "Serviços Operacionais",
      description: "Profissionais treinados para garantir fluidez, segurança e excelência no seu evento.",
      icon: Users,
      color: "bg-gradient-primary",
      services: [
        "Agentes de limpeza",
        "Carregadores",
        "Controladores de acesso",
        "Manobristas",
        "Montadores",
        "Recepcionistas"
      ]
    },
    {
      title: "Serviços Especializados",
      description: "Profissionais especializados para atender às necessidades específicas do seu evento.",
      icon: Shield,
      color: "bg-gradient-secondary",
      services: [
        "Segurança especializada",
        "Brigadistas certificados",
        "Tradutores profissionais",
        "Coordenadores de evento",
        "Técnicos especializados"
      ]
    },
    {
      title: "Locação de Equipamentos",
      description: "Soluções práticas e completas para apoio logístico e operacional.",
      icon: Settings,
      color: "bg-gradient-primary",
      services: [
        "Barreiras de segurança",
        "Capacetes",
        "Detector de metais",
        "Lixeiras",
        "Rádios",
        "Sinalizadores"
      ]
    }
  ];

  const eventTypes = [
    {
      title: "Eventos Corporativos",
      description: "Reuniões empresariais, convenções, lançamentos de produtos, confraternizações, treinamentos e apresentações que fortalecem a imagem da sua empresa.",
      icon: Briefcase,
      features: ["Controle de acesso", "Recepção especializada", "Segurança dedicada", "Limpeza profissional"]
    },
    {
      title: "Cerimônias Oficiais", 
      description: "Formaturas, premiações, inaugurações, homenagens e eventos protocolares que exigem organização impecável e solenidade.",
      icon: UserCheck,
      features: ["Protocolo oficial", "Segurança VIP", "Coordenação especializada", "Suporte logístico"]
    }
  ];

  return (
    <section id="services" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Nossos <span className="text-primary">Serviços</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Oferecemos diversos serviços para garantir que o seu evento seja inesquecível.
          </p>
        </div>

        {/* Service Categories */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          {serviceCategories.map((category, index) => {
            const IconComponent = category.icon;
            return (
              <Card key={index} className="hover:shadow-elegant transition-all duration-300 hover:transform hover:scale-105 border-0">
                <CardHeader className="text-center pb-4">
                  <div className={`inline-flex items-center justify-center w-16 h-16 ${category.color} rounded-full mb-4 mx-auto`}>
                    <IconComponent className="h-8 w-8 text-white" />
                  </div>
                  <CardTitle className="text-2xl">{category.title}</CardTitle>
                  <CardDescription className="text-base">{category.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 gap-3">
                    {category.services.map((service, serviceIndex) => (
                      <div key={serviceIndex} className="flex items-center space-x-3 p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors duration-200">
                        <div className="w-3 h-3 bg-gradient-primary rounded-full flex-shrink-0 shadow-sm" />
                        <span className="text-foreground font-medium">{service}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Event Types */}
        <div className="mb-16">
          <h3 className="text-3xl font-bold text-center mb-12">
            Tipos de <span className="text-primary">Eventos</span>
          </h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {eventTypes.map((eventType, index) => {
              const IconComponent = eventType.icon;
              return (
                <Card key={index} className="p-8 hover:shadow-elegant transition-all duration-300 border-0">
                  <div className="flex items-start space-x-6">
                    <div className="flex-shrink-0">
                      <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-primary rounded-full">
                        <IconComponent className="h-8 w-8 text-white" />
                      </div>
                    </div>
                    <div className="flex-grow">
                      <h4 className="text-2xl font-bold mb-4">{eventType.title}</h4>
                      <p className="text-muted-foreground mb-6">{eventType.description}</p>
                      
                      <div className="grid grid-cols-2 gap-2">
                        {eventType.features.map((feature, featureIndex) => (
                          <div key={featureIndex} className="flex items-center space-x-2">
                            <ClipboardCheck className="h-4 w-4 text-primary" />
                            <span className="text-sm text-foreground">{feature}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <Button 
            variant="hero" 
            size="lg" 
            className="text-lg px-8 py-4"
            onClick={() => window.open('https://wa.me/553199057590', '_blank')}
          >
            Solicite um Orçamento Personalizado
          </Button>
        </div>
      </div>
    </section>
  );
};