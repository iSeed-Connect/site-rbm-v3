import { Instagram, Mail, Phone, MapPin } from "lucide-react";
import { WhatsAppIcon } from "./WhatsAppIcon";
import rbmLogo from "@/assets/rbm-logo-final-transparent.png";

export const Footer = () => {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { name: "Início", href: "/" },
    { name: "Sobre", href: "#about" },
    { name: "Serviços", href: "#services" },
    { name: "Depoimentos", href: "#testimonials" },
    { name: "Contato", href: "#contact" },
  ];

  const services = [
    "Eventos Corporativos",
    "Cerimônias Oficiais",
    "Serviços Operacionais",
    "Serviços Especializados",
    "Locação de Equipamentos",
  ];

  const contactInfo = [
    {
      icon: Mail,
      text: "contato@rbmserviceeventos.com.br",
      link: "mailto:contato@rbmserviceeventos.com.br"
    },
    {
      icon: Phone,
      text: "(31) 99905-7590",
      link: "https://wa.me/553199057590"
    },
    {
      icon: MapPin,
      text: "Belo Horizonte, MG",
      link: "#"
    }
  ];

  return (
    <footer className="bg-card border-t border-border">
      <div className="container mx-auto px-4">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 py-16">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <div className="flex justify-center lg:justify-start mb-6">
                <img 
                 src={rbmLogo} 
                 alt="RBM Service e Eventos" 
                 className="h-20 w-auto md:h-24 lg:h-28 object-contain"
                 style={{ 
                   filter: 'drop-shadow(0 2px 8px rgba(0,0,0,0.1))'
                 }}
               />
            </div>
            <p className="text-muted-foreground mb-6 leading-relaxed text-sm">
              Soluções completas para eventos corporativos, governamentais e grandes produções.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Links Rápidos</h4>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                 <li key={index}>
                   <a
                     href={link.href}
                     className="text-muted-foreground hover:text-primary transition-colors duration-300"
                     onClick={(e) => {
                       if (link.href.startsWith('#') && window.location.pathname !== '/') {
                         e.preventDefault();
                         window.location.href = '/' + link.href;
                       } else if (link.href.startsWith('#')) {
                         e.preventDefault();
                         const element = document.getElementById(link.href.substring(1));
                         element?.scrollIntoView({ behavior: 'smooth' });
                       }
                     }}
                   >
                     {link.name}
                   </a>
                 </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Nossos Serviços</h4>
            <ul className="space-y-3">
              {services.map((service, index) => (
                <li key={index}>
                  <span className="text-muted-foreground">{service}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Contato</h4>
            <ul className="space-y-4 mb-6">
              {contactInfo.map((item, index) => {
                const IconComponent = item.icon;
                return (
                  <li key={index} className="flex items-start space-x-3">
                    <IconComponent className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <a
                      href={item.link}
                      className="text-muted-foreground hover:text-primary transition-colors duration-300"
                    >
                      {item.text}
                    </a>
                  </li>
                );
              })}
            </ul>
            
            {/* Social Links */}
            <div>
              <h5 className="text-base font-medium mb-4">Redes Sociais</h5>
              <div className="flex space-x-4">
                <a
                  href="https://www.instagram.com/rbmserviceeventos/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center w-10 h-10 bg-muted rounded-full hover:bg-primary hover:text-primary-foreground transition-colors duration-300"
                >
                  <Instagram className="h-5 w-5" />
                </a>
                <a
                  href="https://wa.me/553199057590"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center w-10 h-10 bg-muted rounded-full hover:bg-green-500 hover:text-white transition-colors duration-300"
                >
                  <WhatsAppIcon className="h-5 w-5" />
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="border-t border-border py-8">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            <div className="text-muted-foreground text-sm">
              {currentYear} Copyright © RBM Service e Eventos. Todos os direitos reservados.
            </div>
            <div className="text-muted-foreground text-sm">
              Desenvolvido por{" "}
              <a
                href="https://agenciaseed.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:underline"
              >
                iSeed Connect
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};