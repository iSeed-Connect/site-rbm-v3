import { Button } from "@/components/ui/button";
import { ArrowRight, Phone } from "lucide-react";
import heroImage from "@/assets/hero-events.jpg";

export const Hero = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-28">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0">
        <img 
          src={heroImage} 
          alt="Eventos RBM" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-hero opacity-90" />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 sm:px-6 text-center text-white animate-fade-in">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-8 leading-tight">
            Servir com{" "}
            <span className="text-secondary animate-bounce-subtle">excelência</span>{" "}
            promovendo eventos{" "}
            <span className="text-secondary animate-bounce-subtle">memoráveis</span>
          </h1>
          
          <p className="text-lg sm:text-xl md:text-2xl mb-12 text-white/90 max-w-3xl mx-auto leading-relaxed px-4">
            A RBM é sua parceira em cada detalhe, com excelência, dedicação e compromisso 
            proporcionamos uma experiência inesquecível.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12 px-4">
            <Button 
              variant="cta" 
              size="lg" 
              className="text-base sm:text-lg px-6 sm:px-8 py-3 sm:py-4 w-full sm:w-auto hover:scale-105 transition-transform duration-300"
              onClick={() => window.open('https://wa.me/553199057590', '_blank', 'noopener,noreferrer')}
            >
              <Phone className="mr-2 h-4 sm:h-5 w-4 sm:w-5" />
              Solicitar Orçamento
            </Button>
            
            <Button 
              variant="outline" 
              size="lg" 
              className="text-base sm:text-lg px-6 sm:px-8 py-3 sm:py-4 w-full sm:w-auto text-white border-white hover:bg-white hover:text-primary hover:scale-105 transition-all duration-300"
              onClick={() => {
                document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              Conheça Nossos Serviços
              <ArrowRight className="ml-2 h-4 sm:h-5 w-4 sm:w-5" />
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8 max-w-2xl mx-auto px-4">
            <div className="text-center transform hover:scale-105 transition-transform duration-300">
              <div className="text-3xl sm:text-4xl font-bold text-secondary mb-2">20+</div>
              <div className="text-white/80 text-sm sm:text-base">Anos de Experiência</div>
            </div>
            <div className="text-center transform hover:scale-105 transition-transform duration-300">
              <div className="text-3xl sm:text-4xl font-bold text-secondary mb-2">500+</div>
              <div className="text-white/80 text-sm sm:text-base">Eventos Realizados</div>
            </div>
            <div className="text-center transform hover:scale-105 transition-transform duration-300">
              <div className="text-3xl sm:text-4xl font-bold text-secondary mb-2">100%</div>
              <div className="text-white/80 text-sm sm:text-base">Satisfação dos Clientes</div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/60 rounded-full mt-2 animate-pulse" />
        </div>
      </div>
    </section>
  );
};