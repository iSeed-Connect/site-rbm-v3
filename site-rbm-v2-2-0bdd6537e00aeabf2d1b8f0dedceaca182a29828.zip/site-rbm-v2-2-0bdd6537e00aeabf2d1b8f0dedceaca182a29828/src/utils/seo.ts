// SEO utilities for dynamic meta tags
export interface SEOConfig {
  title: string;
  description: string;
  keywords?: string;
  canonical?: string;
  ogImage?: string;
  ogType?: string;
}

export const updatePageSEO = (config: SEOConfig) => {
  // Update document title
  document.title = config.title;
  
  // Update meta description
  updateMetaTag('description', config.description);
  
  // Update keywords if provided
  if (config.keywords) {
    updateMetaTag('keywords', config.keywords);
  }
  
  // Update canonical URL if provided
  if (config.canonical) {
    updateLinkTag('canonical', config.canonical);
  }
  
  // Update Open Graph tags
  updateMetaProperty('og:title', config.title);
  updateMetaProperty('og:description', config.description);
  updateMetaProperty('og:url', config.canonical || window.location.href);
  
  if (config.ogImage) {
    updateMetaProperty('og:image', config.ogImage);
  }
  
  if (config.ogType) {
    updateMetaProperty('og:type', config.ogType);
  }
  
  // Update Twitter Card tags
  updateMetaTag('twitter:title', config.title, 'name');
  updateMetaTag('twitter:description', config.description, 'name');
  
  if (config.ogImage) {
    updateMetaTag('twitter:image', config.ogImage, 'name');
  }
};

const updateMetaTag = (name: string, content: string, attribute = 'name') => {
  let element = document.querySelector(`meta[${attribute}="${name}"]`);
  
  if (!element) {
    element = document.createElement('meta');
    element.setAttribute(attribute, name);
    document.head.appendChild(element);
  }
  
  element.setAttribute('content', content);
};

const updateMetaProperty = (property: string, content: string) => {
  let element = document.querySelector(`meta[property="${property}"]`);
  
  if (!element) {
    element = document.createElement('meta');
    element.setAttribute('property', property);
    document.head.appendChild(element);
  }
  
  element.setAttribute('content', content);
};

const updateLinkTag = (rel: string, href: string) => {
  let element = document.querySelector(`link[rel="${rel}"]`);
  
  if (!element) {
    element = document.createElement('link');
    element.setAttribute('rel', rel);
    document.head.appendChild(element);
  }
  
  element.setAttribute('href', href);
};

// Predefined SEO configurations for each page
export const seoConfigs = {
  home: {
    title: 'RBM Service e Eventos - Excelência em Eventos Corporativos e Institucionais',
    description: 'RBM Service e Eventos - Mais de 20 anos transformando eventos em experiências inesquecíveis. Serviços especializados para eventos corporativos, institucionais e governamentais em Minas Gerais.',
    keywords: 'eventos corporativos, eventos institucionais, eventos governamentais, organização de eventos, Belo Horizonte, Minas Gerais, RBM, recepcionistas, cerimonial, segurança',
    canonical: 'https://rbmserviceeventos.com.br/',
    ogImage: 'https://rbmserviceeventos.com.br/hero-events.jpg',
    ogType: 'website'
  },
  gallery: {
    title: 'Galeria de Eventos - RBM Service e Eventos',
    description: 'Confira nossa galeria com os melhores momentos dos eventos corporativos, institucionais e sociais realizados pela RBM Service e Eventos.',
    keywords: 'galeria eventos, fotos eventos corporativos, eventos realizados RBM, portfolio eventos',
    canonical: 'https://rbmserviceeventos.com.br/gallery',
    ogImage: 'https://rbmserviceeventos.com.br/gallery-corporate-1.jpg',
    ogType: 'website'
  },
  trabalheConosco: {
    title: 'Trabalhe Conosco - RBM Service e Eventos | Vagas de Emprego',
    description: 'Faça parte da equipe RBM! Oportunidades de trabalho em eventos: recepcionistas, garçons, segurança, cerimonial, som e áudio, limpeza e mais.',
    keywords: 'vagas emprego eventos, trabalhar eventos BH, recepcionista eventos, garçom eventos, segurança eventos, RBM vagas',
    canonical: 'https://rbmserviceeventos.com.br/trabalhe-conosco',
    ogImage: 'https://rbmserviceeventos.com.br/team-event-final.jpg',
    ogType: 'website'
  }
};