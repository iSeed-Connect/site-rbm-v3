// Security utilities

// Sanitize user input to prevent XSS
export const sanitizeInput = (input: string): string => {
  const element = document.createElement('div');
  element.textContent = input;
  return element.innerHTML;
};

// Validate email format more strictly
export const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  return emailRegex.test(email) && email.length <= 254;
};

// Validate Brazilian phone number
export const isValidBrazilianPhone = (phone: string): boolean => {
  const phoneRegex = /^\(\d{2}\)\s\d{4,5}-\d{4}$/;
  return phoneRegex.test(phone);
};

// Validate Brazilian CPF
export const isValidCPF = (cpf: string): boolean => {
  // Remove formatting
  const cleanCPF = cpf.replace(/\D/g, '');
  
  // Check if has 11 digits
  if (cleanCPF.length !== 11) return false;
  
  // Check if all digits are the same (invalid CPF)
  if (/^(\d)\1{10}$/.test(cleanCPF)) return false;
  
  // Validate CPF algorithm
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += parseInt(cleanCPF.charAt(i)) * (10 - i);
  }
  let digit1 = 11 - (sum % 11);
  if (digit1 >= 10) digit1 = 0;
  
  sum = 0;
  for (let i = 0; i < 10; i++) {
    sum += parseInt(cleanCPF.charAt(i)) * (11 - i);
  }
  let digit2 = 11 - (sum % 11);
  if (digit2 >= 10) digit2 = 0;
  
  return digit1 === parseInt(cleanCPF.charAt(9)) && digit2 === parseInt(cleanCPF.charAt(10));
};

// Rate limiting for form submissions
class RateLimiter {
  private attempts: Map<string, number[]> = new Map();
  
  isAllowed(key: string, maxAttempts: number = 5, windowMs: number = 60000): boolean {
    const now = Date.now();
    const attempts = this.attempts.get(key) || [];
    
    // Filter out old attempts
    const recentAttempts = attempts.filter(time => now - time < windowMs);
    
    if (recentAttempts.length >= maxAttempts) {
      return false;
    }
    
    recentAttempts.push(now);
    this.attempts.set(key, recentAttempts);
    return true;
  }
  
  reset(key: string): void {
    this.attempts.delete(key);
  }
}

export const rateLimiter = new RateLimiter();

// Content Security Policy helper
// export const setupCSP = () => {
//   // This would typically be set on the server, but we can add some client-side security headers
//   const meta = document.createElement('meta');
//   meta.httpEquiv = 'Content-Security-Policy';
//   meta.content = `
//     default-src 'self'; 
//     script-src 'self' 'unsafe-inline' https://n8n.main.iseed.cloud; 
//     style-src 'self' 'unsafe-inline'; 
//     img-src 'self' data: https:; 
//     connect-src 'self' https://n8n.main.iseed.cloud https://wa.me; 
//     frame-ancestors 'none';
//   `.replace(/\s+/g, ' ').trim();
//   
//   document.head.appendChild(meta);
// };

// Prevent clickjacking
// export const preventClickjacking = () => {
//   if (window.top !== window.self) {
//     window.top!.location.href = window.location.href;
//   }
// };