import { useState, useEffect } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { updatePageSEO, seoConfigs } from "@/utils/seo";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { ChevronLeft, ChevronRight, Eye, Calendar, MapPin } from "lucide-react";

// Import gallery images
import carnavalBH25Img from "@/assets/Carnaval BH 2025 - RBM Service e Eventos.jpg";
import carnavalBH25Img0 from "@/assets/Carnaval BH 2025 - RBM Service e Eventos 0.jpg";
import carnavalBH25Img1 from "@/assets/Carnaval BH 2025 - RBM Service e Eventos 1.jpg";
import carnavalBH25Img2 from "@/assets/Carnaval BH 2025 - RBM Service e Eventos 2.jpg";
import carnavalBH25Img3 from "@/assets/Carnaval BH 2025 - RBM Service e Eventos 3.jpg";
import carnavalBH25Img4 from "@/assets/Carnaval BH 2025 - RBM Service e Eventos 4.jpg";
import carnavalBH25Img5 from "@/assets/Carnaval BH 2025 - RBM Service e Eventos 5.jpg";

import segovOnibusImg from "@/assets/SEGOV - Entrega de onibus Sabará - RBM.jpg";
import segovOnibusImg0 from "@/assets/SEGOV - Entrega de onibus Sabará - RBM 0.jpg";
import segovOnibusImg1 from "@/assets/SEGOV - Entrega de onibus Sabará - RBM 1.jpg";
import segovOnibusImg3 from "@/assets/SEGOV - Entrega de onibus Sabará - RBM 3.jpg";
import segovOnibusImg4 from "@/assets/SEGOV - Entrega de onibus Sabará - RBM 4.jpg";
import segovOnibusImg5 from "@/assets/SEGOV - Entrega de onibus Sabará - RBM 5.jpg";

// Novas imagens TJMG
import natalTJMG from "@/assets/Natal TJMG - Equipe RBM service eventos.jpg";
import natalTJMG1 from "@/assets/Natal TJMG - Equipe RBM service eventos 1.jpg";
import natalTJMG2 from "@/assets/Natal TJMG - Equipe RBM service eventos 2.jpg";
import natalTJMG3 from "@/assets/Natal TJMG - Equipe RBM service eventos 3.jpg";
import natalTJMG4 from "@/assets/Natal TJMG - Equipe RBM service eventos 4.jpg";
import natalTJMG5 from "@/assets/Natal TJMG - Equipe RBM service eventos 5.jpg";
import tjmgEquipe from "@/assets/TJMG - Equipe RBM service eventos.jpg";
import tjmgEquipe1 from "@/assets/TJMG - Equipe RBM service eventos 1.jpg";

// Novas imagens Brasif
import brasifImg1 from "@/assets/Brasif-maquinas-rbm-service-eventos.jpg";
import brasifImg2 from "@/assets/Brasif-maquinas-rbm-service-eventos-2.jpg";
import brasifImg3 from "@/assets/Brasif-maquinas-rbm-service-eventos-3.jpg";
import brasifImg4 from "@/assets/Brasif-maquinas-rbm-service-eventos-4.jpg";

interface GalleryImage {
  id: string;
  src: string;
  alt: string;
}

interface Album {
  id: string;
  title: string;
  description: string;
  date: string;
  location: string;
  category: string;
  coverImage: string;
  images: GalleryImage[];
}

// Dados de exemplo - fácil de expandir
const albums: Album[] = [
  {
    id: "1",
    title: "Evento Corporativo - Brasif Máquinas 2025",
    description: "Dia de negócios, lançamentos e celebração de uma trajetória de mais de 60 anos de consistência.",
    date: "15 de Janeiro, 2025",
    location: "Centro de Convenções BH",
    category: "Corporativo",
    coverImage: brasifImg1,
    images: [
      { id: "1", src: brasifImg1, alt: "Brasif Máquinas - Equipe de segurança" },
      { id: "2", src: brasifImg2, alt: "Brasif Máquinas - Recepção" },
      { id: "3", src: brasifImg3, alt: "Brasif Máquinas - Recepção" },
      { id: "4", src: brasifImg4, alt: "Brasif Máquinas - Equipe" },
    ]
  },
  {
    id: "2",
    title: "Cerimônias Oficiais - TJMG",
    description: "Natal solidário TJMG, Workshops, Solenidades...",
    date: "20 de Dezembro, 2024",
    location: "Tribunal de Justiça MG",
    category: "Acadêmico",
    coverImage: natalTJMG,
    images: [
      { id: "1", src: natalTJMG, alt: "TJMG - Natal solidário" },
      { id: "2", src: natalTJMG1, alt: "TJMG - Natal solidário 1" },
      { id: "3", src: natalTJMG2, alt: "TJMG - Natal solidário 2" },
      { id: "4", src: natalTJMG3, alt: "TJMG - Natal solidário 3" },
      { id: "5", src: natalTJMG4, alt: "TJMG - Natal solidário 4" },
      { id: "6", src: natalTJMG5, alt: "TJMG - Natal solidário 5" },
      { id: "7", src: tjmgEquipe, alt: "TJMG - Equipe" },
      { id: "8", src: tjmgEquipe1, alt: "TJMG - Equipe 1" },
    ]
  },
  {
    id: "3",
    title: "Carnaval Belo Horizonte 2025",
    description: "Alegria que tomou conta das ruas, blocos, cores e sorrisos que transformaram BH na maior festa do ano!",
    date: "Março, 2025",
    location: "Belo Horizonte - MG",
    category: "Cultural",
    coverImage: carnavalBH25Img0,
    images: [
      { id: "1", src: carnavalBH25Img, alt: "Carnaval BH 2025 - RBM Service e Eventos" },
      { id: "2", src: carnavalBH25Img0, alt: "Carnaval BH 2025 - RBM Service e Eventos 0" },
      { id: "3", src: carnavalBH25Img1, alt: "Carnaval BH 2025 - RBM Service e Eventos 1" },
      { id: "4", src: carnavalBH25Img2, alt: "Carnaval BH 2025 - RBM Service e Eventos 2" },
      { id: "5", src: carnavalBH25Img3, alt: "Carnaval BH 2025 - RBM Service e Eventos 3" },
      { id: "6", src: carnavalBH25Img4, alt: "Carnaval BH 2025 - RBM Service e Eventos 4" },
      { id: "7", src: carnavalBH25Img5, alt: "Carnaval BH 2025 - RBM Service e Eventos 5" },
    ]
  },
  {
    id: "4",
    title: "SEGOV - Entrega de Ônibus em Sabará",
    description: "Mais um passo importante para a mobilidade da cidade: entrega oficial de novos ônibus para a população de Sabará, em parceria com a SEGOV. 🚍🤝",
    date: "Outubro, 2024",
    location: "Sabará - MG",
    category: "Social",
    coverImage: segovOnibusImg0,
    images: [
      { id: "1", src: segovOnibusImg0, alt: "SEGOV - Entrega de onibus Sabará - RBM 0" },
      { id: "2", src: segovOnibusImg, alt: "SEGOV - Entrega de onibus Sabará - RBM" },
      { id: "3", src: segovOnibusImg1, alt: "SEGOV - Entrega de onibus Sabará - RBM 1" },
      { id: "4", src: segovOnibusImg3, alt: "SEGOV - Entrega de onibus Sabará - RBM 3" },
      { id: "5", src: segovOnibusImg4, alt: "SEGOV - Entrega de onibus Sabará - RBM 4" },
      { id: "6", src: segovOnibusImg5, alt: "SEGOV - Entrega de onibus Sabará - RBM 5" },
    ]
  }
];

const Gallery = () => {
  const [selectedAlbum, setSelectedAlbum] = useState<Album | null>(null);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [filter, setFilter] = useState<string>("Todos");

  useEffect(() => {
    updatePageSEO(seoConfigs.gallery);
    window.scrollTo(0, 0);
  }, []);

  const categories = ["Todos", "Corporativo", "Acadêmico", "Cultural", "Social"];
  
  const filteredAlbums = filter === "Todos" 
    ? albums 
    : albums.filter(album => album.category === filter);

  const nextImage = () => {
    if (selectedAlbum) {
      setSelectedImageIndex((prev) => 
        prev === selectedAlbum.images.length - 1 ? 0 : prev + 1
      );
    }
  };

  const prevImage = () => {
    if (selectedAlbum) {
      setSelectedImageIndex((prev) => 
        prev === 0 ? selectedAlbum.images.length - 1 : prev - 1
      );
    }
  };

  return (
    <main className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="relative pt-36 md:pt-40 lg:pt-48 pb-20 bg-gradient-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6">
            Nossa <span className="text-accent">Galeria</span>
          </h1>
          <p className="text-lg sm:text-xl md:text-2xl max-w-4xl mx-auto text-white/90 px-4">
            Confira os momentos especiais que criamos em nossos eventos
          </p>
        </div>
      </section>

        {/* Filters */}
        <section className="py-8 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="flex flex-wrap justify-center gap-2 sm:gap-3">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={filter === category ? "default" : "outline"}
                  onClick={() => setFilter(category)}
                  className="text-sm sm:text-base min-w-[100px] sm:min-w-[120px] px-3 sm:px-4"
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>
        </section>

      {/* Albums Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredAlbums.map((album) => (
              <Card key={album.id} className="group cursor-pointer hover:shadow-elegant transition-all duration-300 border-0 overflow-hidden">
                <div className="relative overflow-hidden">
                  <img 
                    src={album.coverImage} 
                    alt={album.title}
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500 cursor-pointer"
                    onClick={() => {
                      setSelectedAlbum(album);
                      setSelectedImageIndex(0);
                      setIsDialogOpen(true);
                    }}
                  />
                  <div className="absolute top-4 left-4">
                    <Badge variant="secondary" className="bg-background/90 text-foreground">
                      {album.category}
                    </Badge>
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  <Button 
                    variant="hero"
                    size="sm"
                    className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                    onClick={() => {
                      setSelectedAlbum(album);
                      setSelectedImageIndex(0);
                      setIsDialogOpen(true);
                    }}
                  >
                    <Eye className="h-4 w-4 mr-2" />
                    Ver Álbum
                  </Button>
                </div>
                
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-2 group-hover:text-primary transition-colors">
                    {album.title}
                  </h3>
                  <p className="text-muted-foreground mb-4 line-clamp-2">
                    {album.description}
                  </p>
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <div className="flex items-center space-x-1">
                      <Calendar className="h-4 w-4" />
                      <span>{album.date}</span>
                    </div>
                    <span className="font-medium">{album.images.length} fotos</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Album Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh] p-0">
          {selectedAlbum && (
            <div className="grid md:grid-cols-2 h-full">
              {/* Image Viewer */}
              <div className="relative bg-black flex items-center justify-center">
                <img 
                  src={selectedAlbum.images[selectedImageIndex]?.src} 
                  alt={selectedAlbum.images[selectedImageIndex]?.alt}
                  className="max-w-full max-h-full object-contain"
                />
                
                {/* Navigation Arrows */}
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/75 text-white"
                  onClick={prevImage}
                >
                  <ChevronLeft className="h-6 w-6" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/75 text-white"
                  onClick={nextImage}
                >
                  <ChevronRight className="h-6 w-6" />
                </Button>
                
                {/* Image Counter */}
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/75 text-white px-3 py-1 rounded-full text-sm">
                  {selectedImageIndex + 1} / {selectedAlbum.images.length}
                </div>
              </div>
              
              {/* Album Info */}
              <div className="p-8 bg-background overflow-y-auto">
                <h3 className="text-2xl font-bold mb-4">{selectedAlbum.title}</h3>
                <p className="text-muted-foreground mb-6">{selectedAlbum.description}</p>
                
                <div className="space-y-3 mb-6">
                  <div className="flex items-center space-x-2 text-sm">
                    <Calendar className="h-4 w-4 text-primary" />
                    <span>{selectedAlbum.date}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <MapPin className="h-4 w-4 text-primary" />
                    <span>{selectedAlbum.location}</span>
                  </div>
                </div>
                
                {/* Thumbnail Grid */}
                <div className="grid grid-cols-3 gap-2">
                  {selectedAlbum.images.map((image, index) => (
                    <button
                      key={image.id}
                      onClick={() => setSelectedImageIndex(index)}
                      className={`relative aspect-square overflow-hidden rounded-lg border-2 transition-all ${
                        index === selectedImageIndex 
                          ? 'border-primary shadow-md' 
                          : 'border-transparent hover:border-primary/50'
                      }`}
                    >
                      <img 
                        src={image.src} 
                        alt={image.alt}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Footer />
    </main>
  );
};

export default Gallery;