import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { updatePageSEO, seoConfigs } from "@/utils/seo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { 
  Users, 
  Briefcase, 
  Award, 
  Clock, 
  Send,
  Mic,
  Utensils,
  Car,
  Shield,
  Loader2,
  CalendarIcon
} from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { useToast } from "@/components/ui/use-toast";

const formSchema = z.object({
  name: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  email: z.string().email("Email inválido"),
  phone: z.string().regex(/^\(\d{2}\)\s\d{4,5}-\d{4}$/, "Telefone deve ter formato (XX) XXXXX-XXXX ou (XX) XXXX-XXXX"),
  cep: z.string().min(8, "CEP é obrigatório"),
  logradouro: z.string().min(2, "Logradouro é obrigatório"),
  numero: z.string().min(1, "Número é obrigatório"),
  complemento: z.string().optional(),
  bairro: z.string().min(2, "Bairro é obrigatório"),
  cidade: z.string().min(2, "Cidade é obrigatória"),
  uf: z.string().min(2, "UF é obrigatório"),
  cpf: z.string().regex(/^\d{3}\.\d{3}\.\d{3}-\d{2}$/, "CPF deve ter formato XXX.XXX.XXX-XX"),
  motherName: z.string().min(2, "Nome da mãe deve ter pelo menos 2 caracteres"),
  birthDate: z.string().min(1, "Data de nascimento é obrigatória"),
  experienceYears: z.string().min(1, "Campo obrigatório"),
  hasEventExperience: z.string().min(1, "Campo obrigatório"),
  services: z.array(z.string()).min(1, "Selecione pelo menos um tipo de serviço"),
  availability: z.array(z.string()).min(1, "Selecione pelo menos uma opção de disponibilidade"),
  cnhCategory: z.string().min(1, "Campo obrigatório"),
  hasOwnTransport: z.string().min(1, "Campo obrigatório"),
  canTravel: z.string().min(1, "Campo obrigatório"),
  smokesOrDrinks: z.string().min(1, "Campo obrigatório"),
  altura: z.string().optional(),
  languages: z.array(z.string()),
  education: z.string(),
  certifications: z.string().optional(),
  motivation: z.string().min(10, "Motivação deve ter pelo menos 10 caracteres"),
  salary: z.string().optional(),
  references: z.string().optional(),
});

const WorkWithUs = () => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  
  useEffect(() => {
    updatePageSEO(seoConfigs.trabalheConosco);
    window.scrollTo(0, 0);
  }, []);
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      cep: "",
      logradouro: "",
      numero: "",
      complemento: "",
      bairro: "",
      cidade: "",
      uf: "",
      cpf: "",
      motherName: "",
      birthDate: "",
      experienceYears: "",
      hasEventExperience: "",
      services: [],
      availability: [],
      cnhCategory: "",
      hasOwnTransport: "",
      canTravel: "",
      smokesOrDrinks: "",
      altura: "",
      languages: [],
      education: "",
      certifications: "",
      motivation: "",
      salary: "",
      references: "",
    },
  });

  const serviceTypes = [
    { id: "recepcionista", label: "Recepcionista", icon: Users },
    { id: "cerimonial", label: "Cerimonial", icon: Award },
    { id: "coordenacao", label: "Coordenação de Eventos", icon: Briefcase },
    { id: "seguranca", label: "Segurança", icon: Shield },
    { id: "controlador_acesso", label: "Controlador(a) de Acesso", icon: Shield },
    { id: "brigadista", label: "Brigadista", icon: Shield },
    { id: "controlador_estacionamento", label: "Controlador(a) de Estacionamento", icon: Car },
    { id: "manobrista", label: "Manobrista", icon: Car },
    { id: "limpeza", label: "Agente de Limpeza", icon: Clock },
    { id: "montador", label: "Montador(a)", icon: Car },
    { id: "carregador", label: "Carregador(a)", icon: Car },
    { id: "garcom", label: "Garçom/Garçonete", icon: Utensils },
    { id: "bartender", label: "Bartender", icon: Utensils },
    { id: "copeiro", label: "Copeiro(a)", icon: Utensils },
    { id: "cozinheiro", label: "Cozinheiro(a)", icon: Utensils },
    { id: "caixa_movel", label: "Caixa Móvel", icon: Users }
  ];

  const availabilityOptions = [
    "Segunda a Sexta",
    "Fins de Semana",
    "Feriados",
    "Noturno"
  ];

  const languageOptions = [
    "Inglês",
    "Espanhol",
    "Francês",
    "Italiano",
    "Alemão"
  ];

  const formatPhone = (value: string) => {
    // Remove tudo que não é número
    const cleaned = value.replace(/\D/g, '');
    
    // Se tem até 2 dígitos, mostra apenas os números
    if (cleaned.length <= 2) return cleaned;
    
    // Se tem até 6 dígitos, formata como (XX) XXXX
    if (cleaned.length <= 6) {
      return `(${cleaned.slice(0, 2)}) ${cleaned.slice(2)}`;
    }
    
    // Se tem até 7 dígitos, formata como (XX) XXXX-X
    if (cleaned.length <= 7) {
      return `(${cleaned.slice(0, 2)}) ${cleaned.slice(2, 6)}-${cleaned.slice(6)}`;
    }
    
    // Se tem 8 ou 9 dígitos (sem contar o DDD), formata completo
    if (cleaned.length <= 10) {
      return `(${cleaned.slice(0, 2)}) ${cleaned.slice(2, 6)}-${cleaned.slice(6, 10)}`;
    }
    
    // Para números com 11 dígitos (9 dígitos + DDD)
    return `(${cleaned.slice(0, 2)}) ${cleaned.slice(2, 7)}-${cleaned.slice(7, 11)}`;
  };

  const formatCPF = (value: string) => {
    // Remove tudo que não é número
    const cleaned = value.replace(/\D/g, '');
    
    // Limit to 11 digits (CPF max length)
    const limited = cleaned.slice(0, 11);
    
    // Se tem até 3 dígitos, mostra apenas os números
    if (limited.length <= 3) return limited;
    
    // Se tem até 6 dígitos, formata como XXX.XXX
    if (limited.length <= 6) {
      return `${limited.slice(0, 3)}.${limited.slice(3)}`;
    }
    
    // Se tem até 9 dígitos, formata como XXX.XXX.XXX
    if (limited.length <= 9) {
      return `${limited.slice(0, 3)}.${limited.slice(3, 6)}.${limited.slice(6)}`;
    }
    
    // Para CPF completo com 11 dígitos
    return `${limited.slice(0, 3)}.${limited.slice(3, 6)}.${limited.slice(6, 9)}-${limited.slice(9, 11)}`;
  };

  const formatCEP = (value: string) => {
    const cleaned = value.replace(/\D/g, '');
    const limited = cleaned.slice(0, 8);
    
    if (limited.length <= 5) return limited;
    return `${limited.slice(0, 5)}-${limited.slice(5)}`;
  };

  const formatBirthDate = (value: string) => {
    // Remove tudo que não é número
    const cleaned = value.replace(/\D/g, '');
    const limited = cleaned.slice(0, 8);
    
    // Se tem até 2 dígitos, mostra apenas os números (DD)
    if (limited.length <= 2) return limited;
    
    // Se tem até 4 dígitos, formata como DD/MM
    if (limited.length <= 4) {
      return `${limited.slice(0, 2)}/${limited.slice(2)}`;
    }
    
    // Para 8 dígitos ou menos, formata como DD/MM/YYYY
    return `${limited.slice(0, 2)}/${limited.slice(2, 4)}/${limited.slice(4)}`;
  };

  const convertDateToISO = (dateStr: string) => {
    // Se já está no formato ISO (YYYY-MM-DD), retorna como está
    if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
      return dateStr;
    }
    
    // Se está no formato DD/MM/YYYY, converte para ISO
    if (/^\d{2}\/\d{2}\/\d{4}$/.test(dateStr)) {
      const [day, month, year] = dateStr.split('/');
      return `${year}-${month}-${day}`;
    }
    
    return dateStr;
  };

  const convertISOToDisplay = (isoDate: string) => {
    // Se está no formato ISO (YYYY-MM-DD), converte para DD/MM/YYYY
    if (/^\d{4}-\d{2}-\d{2}$/.test(isoDate)) {
      const [year, month, day] = isoDate.split('-');
      return `${day}/${month}/${year}`;
    }
    
    return isoDate;
  };

  // Função para limpar os campos de endereço
  const clearAddressFields = () => {
    form.setValue('logradouro', '');
    form.setValue('bairro', '');
    form.setValue('cidade', '');
    form.setValue('uf', '');
    form.setValue('numero', ''); // Limpar número também
    form.setValue('complemento', ''); // Limpar complemento também
  };

  const handleCepChange = async (cep: string, onChange: (value: string) => void) => {
    const cleanedCep = cep.replace(/\D/g, '');
    const formattedCep = formatCEP(cep);
    onChange(formattedCep);
    
    form.clearErrors('cep'); // Limpar erros anteriores do campo CEP

    // Se o CEP é incompleto, limpa os campos de endereço
    if (cleanedCep.length < 8) {
      clearAddressFields();
      return;
    }

    // Se o CEP tem 8 dígitos, tenta buscar o endereço
    if (cleanedCep.length === 8) {
      setIsLoading(true); // Iniciar carregamento
      clearAddressFields(); // Limpa os campos antes de uma nova busca para evitar dados antigos
      try {
        const response = await fetch(`https://viacep.com.br/ws/${cleanedCep}/json/`);
        const data = await response.json();

        if (!data.erro) {
          form.setValue('logradouro', data.logradouro || '');
          form.setValue('bairro', data.bairro || '');
          form.setValue('cidade', data.localidade || '');
          form.setValue('uf', data.uf || '');
          
          toast({
            title: "CEP encontrado!",
            description: `Endereço preenchido automaticamente: ${data.logradouro}, ${data.bairro}`,
          });
        } else {
          form.setError('cep', { message: "CEP não encontrado. Verifique o CEP digitado ou preencha o endereço manualmente." });
          toast({
            title: "CEP não encontrado",
            description: "Verifique o CEP digitado ou preencha o endereço manualmente.",
            variant: "destructive",
          });
        }
      } catch (error) {
        form.setError('cep', { message: "Não foi possível consultar o CEP. Tente novamente ou preencha o endereço manualmente." });
        toast({
          title: "Erro ao buscar CEP",
          description: "Não foi possível consultar o CEP. Preencha o endereço manualmente.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false); // Finalizar carregamento
      }
    }
  };

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    try {
      setIsLoading(true);
      
      // Estrutura os dados para o webhook
      const formData = {
        nome: values.name,
        email: values.email,
        telefone: values.phone,
        cep: values.cep,
        logradouro: values.logradouro,
        numero: values.numero,
        complemento: values.complemento || null,
        bairro: values.bairro,
        cidade: values.cidade,
        uf: values.uf,
        cpf: values.cpf,
        nome_mae: values.motherName,
        data_nascimento: values.birthDate,
        anos_experiencia: values.experienceYears,
        tem_experiencia_eventos: values.hasEventExperience,
        tipos_servicos: values.services,
        disponibilidade: values.availability,
        categoria_cnh: values.cnhCategory || null,
        tem_transporte_proprio: values.hasOwnTransport,
        pode_viajar: values.canTravel,
        fuma_ou_bebe: values.smokesOrDrinks,
        altura: values.altura,
        idiomas: values.languages,
        escolaridade: values.education,
        certificacoes: values.certifications || null,
        motivacao: values.motivation,
        pretensao_salarial: values.salary || null,
        referencias: values.references || null,
        data_candidatura: new Date().toISOString(),
        origem: 'site_rbm'
      };

      const response = await fetch('https://n8n.main.iseed.cloud/webhook/forms/trabalhe-conosco-rbm', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });
      
      if (response.ok) {
        toast({
          title: "Candidatura enviada com sucesso!",
          description: "Entraremos em contato em até 7 dias úteis. Obrigado pelo interesse!",
        });
        form.reset();
      } else {
        throw new Error('Erro no envio');
      }
    } catch (error) {
      toast({
        title: "Erro ao enviar candidatura",
        description: "Tente novamente ou entre em contato via WhatsApp.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="relative pt-36 md:pt-40 lg:pt-48 pb-20 bg-gradient-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6">
            Trabalhe <span className="text-accent">Conosco</span>
          </h1>
          <p className="text-lg sm:text-xl md:text-2xl max-w-4xl mx-auto text-white/90 px-4">
            Faça parte da equipe RBM e ajude a criar eventos inesquecíveis
          </p>
        </div>
      </section>

      {/* Form Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                
                {/* Dados Pessoais */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Users className="h-6 w-6 text-primary" />
                      <span>Dados Pessoais</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nome Completo *</FormLabel>
                            <FormControl>
                              <Input placeholder="Seu nome completo" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email *</FormLabel>
                            <FormControl>
                              <Input type="email" placeholder="seu@email.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Telefone *</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="(31) 99999-9999" 
                                value={field.value}
                                onChange={(e) => {
                                  const formatted = formatPhone(e.target.value);
                                  field.onChange(formatted);
                                }}
                                maxLength={15}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="cpf"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>CPF *</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="000.000.000-00" 
                                value={field.value}
                                onChange={(e) => {
                                  const formatted = formatCPF(e.target.value);
                                  field.onChange(formatted);
                                }}
                                maxLength={14}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="motherName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nome da Mãe *</FormLabel>
                            <FormControl>
                              <Input placeholder="Nome completo da mãe" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="birthDate"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Data de Nascimento *</FormLabel>
                            <div className="flex space-x-2">
                              <FormControl>
                                <Input 
                                  placeholder="DD/MM/AAAA" 
                                  value={field.value ? convertISOToDisplay(field.value) : ''}
                                  onChange={(e) => {
                                    const formatted = formatBirthDate(e.target.value);
                                    // Converte para ISO quando a data está completa
                                    if (formatted.length === 10) {
                                      const isoDate = convertDateToISO(formatted);
                                      field.onChange(isoDate);
                                    } else {
                                      // Para datas incompletas, mantém o formato de exibição
                                      field.onChange(formatted);
                                    }
                                  }}
                                  maxLength={10}
                                  className="flex-1"
                                />
                              </FormControl>
                              <Popover>
                                <PopoverTrigger asChild>
                                  <Button
                                    variant="outline"
                                    type="button"
                                    className={cn(
                                      "w-[40px] h-10 p-0 flex items-center justify-center",
                                      !field.value && "text-muted-foreground"
                                    )}
                                  >
                                    <CalendarIcon className="h-4 w-4" />
                                  </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                  <Calendar
                                    mode="single"
                                    selected={field.value ? new Date(convertDateToISO(field.value)) : undefined}
                                    onSelect={(date) => {
                                      if (date) {
                                        const isoDate = date.toISOString().split('T')[0];
                                        field.onChange(isoDate);
                                      }
                                    }}
                                    disabled={(date) =>
                                      date > new Date() || date < new Date("1900-01-01")
                                    }
                                    initialFocus
                                    className="pointer-events-auto"
                                  />
                                </PopoverContent>
                              </Popover>
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <FormField
                        control={form.control}
                        name="cep"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>CEP *</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="00000-000" 
                                value={field.value}
                                onChange={(e) => handleCepChange(e.target.value, field.onChange)}
                                maxLength={9}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="logradouro"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Rua/Logradouro *</FormLabel>
                            <FormControl>
                              <Input placeholder="Rua, Avenida..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="numero"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Número *</FormLabel>
                            <FormControl>
                              <Input placeholder="123" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <FormField
                        control={form.control}
                        name="complemento"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Complemento</FormLabel>
                            <FormControl>
                              <Input placeholder="Apto, Bloco..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="bairro"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Bairro *</FormLabel>
                            <FormControl>
                              <Input placeholder="Centro, Vila..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="cidade"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Cidade *</FormLabel>
                            <FormControl>
                              <Input placeholder="Sua cidade" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="uf"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>UF *</FormLabel>
                            <FormControl>
                              <Input placeholder="MG" {...field} maxLength={2} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Experiência Profissional */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Briefcase className="h-6 w-6 text-primary" />
                      <span>Experiência Profissional</span>
                    </CardTitle>
                  </CardHeader>
                   <CardContent className="space-y-6">
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                       <FormField
                         control={form.control}
                         name="hasEventExperience"
                         render={({ field }) => (
                           <FormItem>
                             <FormLabel>Já trabalhou em eventos? *</FormLabel>
                             <FormControl>
                               <RadioGroup 
                                 onValueChange={field.onChange} 
                                 defaultValue={field.value}
                                 className="flex space-x-6 mt-2"
                               >
                                 <div className="flex items-center space-x-2">
                                   <RadioGroupItem value="sim" id="exp-sim" />
                                   <Label htmlFor="exp-sim">Sim</Label>
                                 </div>
                                 <div className="flex items-center space-x-2">
                                   <RadioGroupItem value="nao" id="exp-nao" />
                                   <Label htmlFor="exp-nao">Não</Label>
                                 </div>
                               </RadioGroup>
                             </FormControl>
                             <FormMessage />
                           </FormItem>
                         )}
                       />
                       
                       <FormField
                         control={form.control}
                         name="experienceYears"
                         render={({ field }) => (
                           <FormItem>
                             <FormLabel>Tempo de experiência em eventos *</FormLabel>
                             <Select onValueChange={field.onChange} defaultValue={field.value}>
                               <FormControl>
                                 <SelectTrigger>
                                   <SelectValue placeholder="Selecione" />
                                 </SelectTrigger>
                               </FormControl>
                               <SelectContent>
                                 <SelectItem value="iniciante">Iniciante (sem experiência)</SelectItem>
                                 <SelectItem value="1-2">1-2 anos</SelectItem>
                                 <SelectItem value="3-5">3-5 anos</SelectItem>
                                 <SelectItem value="5-10">5-10 anos</SelectItem>
                                 <SelectItem value="10+">Mais de 10 anos</SelectItem>
                               </SelectContent>
                             </Select>
                             <FormMessage />
                           </FormItem>
                         )}
                       />
                     </div>

                    <FormField
                      control={form.control}
                      name="services"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base font-semibold">
                            Tipos de serviços que você tem experiência: *
                          </FormLabel>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {serviceTypes.map((service) => {
                              const IconComponent = service.icon;
                              return (
                                <FormItem
                                  key={service.id}
                                  className="flex flex-row items-center space-x-3 space-y-0"
                                >
                                  <FormControl>
                                    <Checkbox
                                      checked={field.value?.includes(service.id)}
                                      onCheckedChange={(checked) => {
                                        return checked
                                          ? field.onChange([...field.value, service.id])
                                          : field.onChange(
                                              field.value?.filter(
                                                (value) => value !== service.id
                                              )
                                            );
                                      }}
                                    />
                                  </FormControl>
                                  <IconComponent className="h-5 w-5 text-primary" />
                                  <FormLabel className="font-medium">
                                    {service.label}
                                  </FormLabel>
                                </FormItem>
                              );
                            })}
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                 {/* Disponibilidade e Condições Pessoais */}
                 <Card>
                   <CardHeader>
                     <CardTitle className="flex items-center space-x-2">
                       <Clock className="h-6 w-6 text-primary" />
                       <span>Disponibilidade e Condições Pessoais</span>
                     </CardTitle>
                   </CardHeader>
                  <CardContent className="space-y-6">
                        <FormField
                          control={form.control}
                          name="availability"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-base font-semibold">
                                Quando você está disponível para trabalhar? *
                              </FormLabel>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                            {availabilityOptions.map((option) => (
                              <FormItem
                                key={option}
                                className="flex flex-row items-center space-x-3 space-y-0"
                              >
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(option)}
                                    onCheckedChange={(checked) => {
                                      return checked
                                        ? field.onChange([...field.value, option])
                                        : field.onChange(
                                            field.value?.filter(
                                              (value) => value !== option
                                            )
                                          );
                                    }}
                                  />
                                </FormControl>
                                <FormLabel className="font-normal">
                                  {option}
                                </FormLabel>
                              </FormItem>
                            ))}
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                      <FormField
                        control={form.control}
                        name="cnhCategory"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Possui CNH? Qual categoria? *</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Selecione a categoria da CNH" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="nao_possuo">Não possuo CNH</SelectItem>
                                <SelectItem value="A">A - Motocicleta</SelectItem>
                                <SelectItem value="B">B - Carro</SelectItem>
                                <SelectItem value="C">C - Caminhão</SelectItem>
                                <SelectItem value="D">D - Ônibus</SelectItem>
                                <SelectItem value="E">E - Carreta</SelectItem>
                                <SelectItem value="AB">A + B</SelectItem>
                                <SelectItem value="AC">A + C</SelectItem>
                                <SelectItem value="AD">A + D</SelectItem>
                                <SelectItem value="AE">A + E</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                         <FormField
                           control={form.control}
                           name="hasOwnTransport"
                           render={({ field }) => (
                             <FormItem>
                               <FormLabel>Possui transporte próprio? *</FormLabel>
                               <FormControl>
                                 <RadioGroup 
                                   onValueChange={field.onChange} 
                                   defaultValue={field.value}
                                   className="flex space-x-6 mt-2"
                                 >
                                   <div className="flex items-center space-x-2">
                                     <RadioGroupItem value="sim" id="transport-sim" />
                                     <Label htmlFor="transport-sim">Sim</Label>
                                   </div>
                                   <div className="flex items-center space-x-2">
                                     <RadioGroupItem value="nao" id="transport-nao" />
                                     <Label htmlFor="transport-nao">Não</Label>
                                   </div>
                                 </RadioGroup>
                               </FormControl>
                               <FormMessage />
                             </FormItem>
                           )}
                         />
                         
                         <FormField
                           control={form.control}
                           name="canTravel"
                           render={({ field }) => (
                             <FormItem>
                               <FormLabel>Disponibilidade para viagens? *</FormLabel>
                               <FormControl>
                                 <RadioGroup 
                                   onValueChange={field.onChange} 
                                   defaultValue={field.value}
                                   className="flex space-x-6 mt-2"
                                 >
                                   <div className="flex items-center space-x-2">
                                     <RadioGroupItem value="sim" id="travel-sim" />
                                     <Label htmlFor="travel-sim">Sim</Label>
                                   </div>
                                   <div className="flex items-center space-x-2">
                                     <RadioGroupItem value="nao" id="travel-nao" />
                                     <Label htmlFor="travel-nao">Não</Label>
                                   </div>
                                 </RadioGroup>
                               </FormControl>
                               <FormMessage />
                             </FormItem>
                           )}
                         />

                         <FormField
                           control={form.control}
                           name="smokesOrDrinks"
                           render={({ field }) => (
                            <FormItem>
                              <FormLabel>Ingere bebida alcoólica e/ou fuma? *</FormLabel>
                              <FormControl>
                                 <RadioGroup 
                                   onValueChange={field.onChange} 
                                   defaultValue={field.value}
                                   className="grid grid-cols-2 gap-3 mt-2"
                                 >
                                   <div className="flex items-center space-x-2">
                                     <RadioGroupItem value="nao_ambos" id="neither" />
                                     <Label htmlFor="neither">Não p/ ambos</Label>
                                   </div>
                                   <div className="flex items-center space-x-2">
                                     <RadioGroupItem value="apenas_bebida" id="drink-only" />
                                     <Label htmlFor="drink-only">Apenas bebida</Label>
                                   </div>
                                   <div className="flex items-center space-x-2">
                                     <RadioGroupItem value="apenas_fuma" id="smoke-only" />
                                     <Label htmlFor="smoke-only">Apenas fuma</Label>
                                   </div>
                                   <div className="flex items-center space-x-2">
                                     <RadioGroupItem value="ambos" id="both" />
                                     <Label htmlFor="both">Ambos</Label>
                                   </div>
                                 </RadioGroup>
                               </FormControl>
                               <FormMessage />
                             </FormItem>
                           )}
                         />

                         <FormField
                           control={form.control}
                           name="altura"
                           render={({ field }) => (
                             <FormItem>
                               <FormLabel>Altura (em cm)</FormLabel>
                               <FormControl>
                                 <Input 
                                   placeholder="170" 
                                   type="number" 
                                   min="140" 
                                   max="220"
                                   {...field} 
                                 />
                               </FormControl>
                               <FormMessage />
                             </FormItem>
                           )}
                         />
                       </div>
                  </CardContent>
                </Card>

                {/* Qualificações */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Award className="h-6 w-6 text-primary" />
                      <span>Qualificações e Competências</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <FormField
                      control={form.control}
                      name="education"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Escolaridade</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Selecione seu nível de escolaridade" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="fundamental">Ensino Fundamental</SelectItem>
                              <SelectItem value="medio">Ensino Médio</SelectItem>
                              <SelectItem value="tecnico">Técnico</SelectItem>
                              <SelectItem value="superior">Ensino Superior</SelectItem>
                              <SelectItem value="pos">Pós-graduação</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="languages"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-base font-semibold">
                            Idiomas que você fala:
                          </FormLabel>
                          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                            {languageOptions.map((language) => (
                              <FormItem
                                key={language}
                                className="flex flex-row items-center space-x-3 space-y-0"
                              >
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(language)}
                                    onCheckedChange={(checked) => {
                                      return checked
                                        ? field.onChange([...field.value, language])
                                        : field.onChange(
                                            field.value?.filter(
                                              (value) => value !== language
                                            )
                                          );
                                    }}
                                  />
                                </FormControl>
                                <FormLabel className="font-normal">
                                  {language}
                                </FormLabel>
                              </FormItem>
                            ))}
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="certifications"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Certificações e Cursos</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Liste suas certificações, cursos técnicos, workshops, etc."
                              rows={3}
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                {/* Informações Adicionais */}
                <Card>
                  <CardHeader>
                    <CardTitle>Informações Adicionais</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <FormField
                      control={form.control}
                      name="motivation"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Por que quer trabalhar com eventos? *</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Conte-nos sua motivação e o que te atrai no mundo dos eventos..."
                              rows={4}
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="salary"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Pretensão salarial</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Ex: R$ 120,00 por evento ou a combinar"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="references"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Referências Profissionais</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Nome, empresa e contato de referências profissionais (opcional)"
                              rows={3}
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                {/* Submit Button */}
                <div className="text-center">
                  <Button 
                    type="submit" 
                    variant="hero" 
                    size="lg" 
                    className="min-w-[200px]"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    ) : (
                      <Send className="mr-2 h-5 w-5" />
                    )}
                    {isLoading ? "Enviando..." : "Enviar Candidatura"}
                  </Button>
                  <p className="text-sm text-muted-foreground mt-4">
                    Analisaremos sua candidatura e entraremos em contato em até 7 dias úteis.
                  </p>
                </div>
              </form>
            </Form>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
};

export default WorkWithUs;