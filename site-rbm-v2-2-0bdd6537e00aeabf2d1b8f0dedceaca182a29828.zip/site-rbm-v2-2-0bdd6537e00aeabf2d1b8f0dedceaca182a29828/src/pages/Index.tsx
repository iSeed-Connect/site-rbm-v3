import { useEffect } from "react";
import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { About } from "@/components/About";
import { Services } from "@/components/Services";
import { PartnersCarousel } from "@/components/PartnersCarousel";
import { Testimonials } from "@/components/Testimonials";
import { Contact } from "@/components/Contact";
import { Footer } from "@/components/Footer";
import { updatePageSEO, seoConfigs } from "@/utils/seo";

const Index = () => {
  useEffect(() => {
    updatePageSEO(seoConfigs.home);
    window.scrollTo(0, 0);
  }, []);

  return (
    <main className="min-h-screen" id="home">
      <Header />
      <Hero />
      <About />
      <Services />
      <PartnersCarousel />
      <Testimonials />
      <Contact />
      <Footer />
    </main>
  );
};

export default Index;
