import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'
import { preloadCriticalResources } from './utils/performance.ts'
// import { setupCSP, preventClickjacking } from './utils/security.ts' // Removendo importação

// Security setup (only in production to avoid blocking dev/preview)
// if (import.meta.env.PROD) {
//   setupCSP();
//   preventClickjacking();
// }

// Preload critical resources
preloadCriticalResources();

createRoot(document.getElementById("root")!).render(<App />);
