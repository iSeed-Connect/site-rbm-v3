# RBM Service e Eventos

Site institucional da RBM Service e Eventos - Empresa especializada em eventos corporativos, institucionais e governamentais.

## 📋 Sobre o Projeto

Este é um site moderno e responsivo desenvolvido para a RBM Service e Eventos, empresa com mais de 20 anos de experiência no mercado de eventos corporativos e institucionais.

## 🚀 Tecnologias Utilizadas

- **React 18** - Framework principal
- **TypeScript** - Tipagem estática
- **Vite** - Build tool e desenvolvimento
- **Tailwind CSS** - Framework de estilização
- **Shadcn/ui** - Componentes UI
- **React Router** - Roteamento
- **Lucide React** - Ícones

## 📦 Deploy na Hostinger

### Pré-requisitos
- Node.js 18+ instalado
- NPM ou Yarn

### Passos para Deploy

1. **Instalar dependências:**
```bash
npm install
```

2. **Build do projeto:**
```bash
npm run build
```

3. **Upload para Hostinger:**
   - Acesse o painel da Hostinger
   - Vá para "Gerenciador de Arquivos"
   - Navegue até a pasta `public_html`
   - Faça upload de todos os arquivos da pasta `dist`

### Estrutura do Build
Após executar `npm run build`, os arquivos estarão na pasta `dist/`:
- `index.html` - Arquivo principal
- `assets/` - CSS, JS e imagens otimizadas
- Todos os assets estáticos

### Configurações Importantes

#### DNS e Domínio
- Configure o domínio para apontar para: `rbmserviceeventos.com.br`
- Certifique-se que o SSL está ativo

#### Redirecionamentos (.htaccess)
Crie um arquivo `.htaccess` na pasta `public_html` com:
```apache
RewriteEngine On
RewriteBase /

# Handle Angular and React Routes
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.html [L]

# Force HTTPS
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# Gzip compression
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/plain
    AddOutputFilterByType DEFLATE text/html
    AddOutputFilterByType DEFLATE text/xml
    AddOutputFilterByType DEFLATE text/css
    AddOutputFilterByType DEFLATE application/xml
    AddOutputFilterByType DEFLATE application/xhtml+xml
    AddOutputFilterByType DEFLATE application/rss+xml
    AddOutputFilterByType DEFLATE application/javascript
    AddOutputFilterByType DEFLATE application/x-javascript
</IfModule>

# Expire headers
<IfModule mod_expires.c>
    ExpiresActive on
    ExpiresByType text/css "access plus 1 year"
    ExpiresByType application/javascript "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
</IfModule>
```

## 🎨 Características do Site

### Design Responsivo
- Layout adaptativo para desktop, tablet e mobile
- Navegação intuitiva
- Performance otimizada

### SEO Otimizado
- Meta tags completas
- Schema.org structured data
- Sitemap XML
- Robots.txt configurado
- URLs amigáveis

### Funcionalidades
- **Homepage:** Hero section com CTAs
- **Sobre:** Informações da empresa
- **Serviços:** Portfólio de serviços
- **Galeria:** Fotos de eventos realizados
- **Trabalhe Conosco:** Formulário de candidatura
- **Contato:** Informações de contato e localização

### Integrações
- WhatsApp Business
- Instagram
- Formulários de contato
- Google Analytics (configurar no deploy)

## 📱 Contato

- **Website:** rbmserviceeventos.com.br
- **WhatsApp:** (31) 99905-7590
- **Instagram:** @rbmserviceeventos
- **Email:** contato@rbmserviceeventos.com.br

## 🔧 Suporte Técnico

Para suporte técnico e atualizações do site, entre em contato com a iSeed Connect.

---

**Desenvolvido por:** iSeed Connect | [agenciaseed.com](https://agenciaseed.com)
